using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Player
{
    public string Nombre { get; set; }
    public int Matados { get; set; }
    public int Asistencias { get; set; }
    public int Muertes { get; set; }
    public int Score
    {
        get
        {
            return Matados * 3 + Asistencias * 1 - Muertes * 1;
        }
    }
    public Player(string nombre, int matados, int asistencias, int muertes)
    {
        Nombre = nombre;
        Matados = matados;
        Asistencias = asistencias;
        Muertes = muertes;
    }
}
