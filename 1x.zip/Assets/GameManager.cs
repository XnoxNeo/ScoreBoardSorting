using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public List<Player> jugadores;
    public GameObject jugadorPrefab; 
    public Transform panelScoreboard; 
    private void Awake()
    {
        panelScoreboard = GetComponent<Transform>();
    }
    void Start()
    {
        jugadores = new List<Player>();
        for (int i = 0; i < 10; i++)
        {
            string nombre = "Player" + (i + 1);
            int matados = Random.Range(0, 50);
            int asistencias = Random.Range(0, 30);
            int muertes = Random.Range(0, 40);
            jugadores.Add(new Player(nombre, matados, asistencias, muertes));
        }
        ActualizarScoreboard();

    }


    public void ActualizarScoreboard()
    {
        foreach (Transform child in panelScoreboard)
        {
            Destroy(child.gameObject);
        }
        foreach (Player jugador in jugadores)
        {
            GameObject jugadorItem = Instantiate(jugadorPrefab, panelScoreboard);
            TMP_Text text = jugadorItem.GetComponent<TMP_Text>();
            text.text = $"{jugador.Nombre}: {jugador.Matados} Kills, {jugador.Asistencias} Assists, {jugador.Muertes} Deaths, {jugador.Score} Score";
        }
    }
}
