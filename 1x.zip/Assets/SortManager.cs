using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class SortManager : MonoBehaviour
{
    public GameManager gameManager;

    public void OrdenarPorMatados()
    {
        Ordenar((j1, j2) => j2.Matados.CompareTo(j1.Matados));
        gameManager.ActualizarScoreboard();
    }

    public void OrdenarPorAsistencias()
    {
        Ordenar((j1, j2) => j2.Asistencias.CompareTo(j1.Asistencias));
        gameManager.ActualizarScoreboard();
    }

    public void OrdenarPorMuertes()
    {
        Ordenar((j1, j2) => j2.Muertes.CompareTo(j1.Muertes));
        gameManager.ActualizarScoreboard();
    }

    public void OrdenarPorScore()
    {
        Ordenar((j1, j2) => j2.Score.CompareTo(j1.Score));
        gameManager.ActualizarScoreboard();
    }

    private void Ordenar(Comparison<Player> comparador)
    {
        Player[] array = gameManager.jugadores.ToArray();
        int n = array.Length;
        for (int i = 0; i < n - 1; i++)
        {
            for (int j = 0; j < n - i - 1; j++)
            {
                if (comparador(array[j], array[j + 1]) > 0)
                {
                    Player temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                }
            }
        }
        gameManager.jugadores = array.ToList();
    }
}
